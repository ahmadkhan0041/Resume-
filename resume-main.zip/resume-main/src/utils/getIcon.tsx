export default function getIcon(url: string) {
  return url + "/favicon.ico";
}
